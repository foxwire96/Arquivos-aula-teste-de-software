package mocktest.mockjava;

public class ApiDosCorreios {
	/**
	 * Classe ficticia que faz o papel de uma integração com a API dos Correios
	 */
	    public DadosLocalizacao buscaDadosComBaseNoCep(String cep) {
	        return null;
	    }

	}